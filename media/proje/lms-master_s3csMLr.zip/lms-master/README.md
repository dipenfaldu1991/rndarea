# Employee Leave Management System

A easy-to-use web application built on Django. Optimal for leave management of employees in academic institutions.

User roles - Admin, Passing Official, Clerk, Leave Application Creator
